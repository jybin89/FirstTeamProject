package com.kh.teampl.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kh.teampl.dao.CheckDao;
import com.kh.teampl.dto.Product_noDto;

@Service
public class CheckService {

	@Autowired
	private CheckDao checkDao;
	
	@Transactional
	public Map<String, Boolean> checkAll(Product_noDto product_noDto) {
		boolean crResult = crCheck(product_noDto);
		boolean cmResult = cmCheck(product_noDto);
		boolean mrResult = mrCheck(product_noDto);
		boolean mvResult = mvCheck(product_noDto);
		boolean msResult = msCheck(product_noDto);
		boolean caseMbResult = caseMbCheck(product_noDto);
		boolean casePowerResult = casePowerCheck(product_noDto);
		boolean caseVgaResult = caseVgaCheck(product_noDto);
		
		Map<String, Boolean> map = new HashMap<>();
		map.put("CPU_RAM", crResult);
		map.put("CPU_MB", cmResult);
		map.put("MB_RAM", mrResult);
		map.put("MB_VGA", mvResult);
		map.put("MB_SSD", msResult);
		map.put("CASE_MB", caseMbResult);
		map.put("CASE_POWER", casePowerResult);
		map.put("CASE_VGA", caseVgaResult);
		
		System.out.println("map" + map);
		return map;
	}

	// cpu ram select
	public boolean crCheck(Product_noDto product_noDto) {
		boolean result = checkDao.crCheck(product_noDto);
		System.out.println("CheckService, crCheck, list: " + result);
		return result;
	}

	// cpu mb select
	public boolean cmCheck(Product_noDto product_noDto) {
		boolean result = checkDao.cmCheck(product_noDto);
		System.out.println("CheckService, cmCheck, result: " + result);
		return result;
	}

	// mb ram select
	public boolean mrCheck(Product_noDto product_noDto) {
		boolean result = checkDao.mrCheck(product_noDto);
		System.out.println("CheckService, mrCheck, result: " + result);
		return result;
	}

	// mb vga select
	public boolean mvCheck(Product_noDto product_noDto) {
		boolean result = checkDao.mvCheck(product_noDto);
		System.out.println("CheckService, mvCheck, result: " + result);
		return result;
	}

	// mb ssd select
	public boolean msCheck(Product_noDto product_noDto) {
		boolean result = checkDao.msCheck(product_noDto);
		System.out.println("CheckService, msCheck, result: " + result);
		return result;
	}
	
	// case mb select
	public boolean caseMbCheck(Product_noDto product_noDto) {
		boolean result = checkDao.caseMbCheck(product_noDto);
		System.out.println("CheckService, casePowerCheck, list: " + result);
		return result;
	}

	// case power select
	public boolean casePowerCheck(Product_noDto product_noDto) {
		boolean result = checkDao.casePowerCheck(product_noDto);
		System.out.println("CheckService, casePowerCheck, result: " + result);
		return result;
	}
	
	// case vga select
	public boolean caseVgaCheck(Product_noDto product_noDto) {
		boolean result = checkDao.caseVgaCheck(product_noDto);
		System.out.println("CheckService, caseVgaCheck, result: " + result);
		return result;
	}
}
