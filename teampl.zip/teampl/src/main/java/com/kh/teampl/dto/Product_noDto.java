package com.kh.teampl.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Product_noDto {
	private int cpu_product_no;
	private int mb_product_no;
	private int ram_product_no;
	private int vga_product_no;
	private int case_product_no;
	private int power_product_no;
	private int ssd_product_no;
	
	
	
}
