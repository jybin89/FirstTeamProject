package com.kh.teampl.vo;

import lombok.Data;

@Data
public class WizardVo {
	private String wizard_no;
	private int wizard_cpu_no;
	private int wizard_mb_no;
	private int wizard_ram_no;
	private int wizard_vga_no;
	private int wizard_power_no;
	private int wizard_case_no;
	private int wizard_ssd_no;
	private int wizard_value;
	private int wizard_price;
	private String imgsrc;
}